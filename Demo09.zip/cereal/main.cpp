#include "structToJson.h"
#include "structToBinary.h"


int main()
{
	/*Json::StructToJson1 sToJson1;
	sToJson1.EncodingDecoding();

	Json::StructToJson2 sToJson2;
	sToJson2.Encoding();
	sToJson2.Decoding();

	Json::StructToJson3 sToJson3;
	sToJson3.EncodingDecoding();

	Json::StructToJson4 sToJson4;
	sToJson4.EncodingDecoding();

	Json::StructToJson5 sToJson5;
	sToJson5.EncodingDecoding();

	Json::StructToJson6::Encoding();

	Json::StructToJson7::Encoding();*/


	Binary::StructToBinary1 sToBinary1;
	sToBinary1.EncodingDecoding();

	Binary::StructToBinary2 sToBinary2;
	sToBinary2.Encoding();
	sToBinary2.Decoding();
	return 0;
}
