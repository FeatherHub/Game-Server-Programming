// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#undef __STRICT_ANSI__


#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#include <vector>
#include <list>
#include <map>
#include <string>
#include <malloc.h>
#include <iostream>
#include <CGDbuffer>



// TODO: reference additional headers your program requires here
