﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.CodeDom;
using System.Linq.Expressions;

namespace LinqToCodedom.Visitors
{
	public static class StaticVisitor
	{
        //public static CodeExpression Visit(this BinaryExpression expression)
        //{
        //    return new CodeExpressionVisitor(null).Visit(expression);
        //}
	}
}
